//function to show Tab
function showTab(tab_id) {
  $("#" + tab_id).tab("show");
}
$(document).ready(function () {
  var rowCount = 1;

  function calculate(row) {
    var quantity = row.find('.quantity').val();
    var price = row.find('.price').val();
    var total = quantity * price;
    row.find('.total').text('Total:' + total);
  }

  $(document).on('click', '.calculate', function () {
    var row = $(this).closest('.row');
    calculate(row);
  });

  $('#add-more').click(function () {
    
    var newRow = '<div id="row' + rowCount + '" class="row">' +

      '<div><label></label>' +
      '<input type="text" class="product-name form-control" id="prod_name1" maxlength="12"></div>' +

      '<div><label></label>' +
      '<input type="number" class="quantity form-control" ></div>' +

      '<div><label></label>' +
      '<input type="number" class="price form-control"></div>' +

      '<div><label>Action:</label><button class="calculate btn btn-primary">Calculate</button></div>' +
      '<span class="total"></span>' +
      '</div>';

    $('#container').append(newRow);
    rowCount++;

    // $('#prod_name1'+rowCount).bind('keyup', function(event){
    //   this.value = this.value.replace(/[^a-z ]/g,'');
    // });

  });

  $('#show-total').click(function () {
    var grandTotal = 0;
    $('.total').each(function () {
      var total = parseInt($(this).text().split(":")[1]);
      if (!isNaN(total)) {
        grandTotal += total;
      }
    });
    $('#all-total').text('Grand Total: ' + grandTotal);
  });

});


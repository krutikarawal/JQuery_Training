$(document).ready(function () {
  // custom validation
  jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z]+$/i.test(value);
  }, "Letters and space only please")

  // form validation
  $("#basic-form").validate({
    rules: {
      txt_username: {
        required: true,
        minlength: 3,
        maxlength: 12,
        lettersonly: true
      },
      txt_password: {
        required: true,
        minlength: 6,
        maxlength: 12
      },
      txt_city: {
        required: true,
        minlength: 3,
        maxlength: 12
      },
      opt_server: {
        required: true
      },
      role: {
        required: true
      },
      chk: {
        required: true
      }
    },
    messages: {
      txt_username: {
        required: 'Please enter username',
        minlength: 'Please enter minimum 3 letters',
        maxlength: 'Please enter maximum 12 letters',
        lettersonly: 'Please enter only letters and spaces',
      },
      txt_password: {
        required: 'Please enter password',
        minlength: 'Please enter minimum 3 letters',
        maxlength: 'Please enter maximum 12 letters',
        lettersonly: 'Please enter only letters and spaces'
      },
      txt_city: {
        required: 'Please enter city',
        minlength: 'Please enter minimum 3 letters',
        maxlength: 'Please enter maximum 12 letters',
        lettersonly: 'Please enter only letters and spaces'
      },
      opt_server: {
        required: 'Please enter server',
      },
      role: {
        required: 'Please enter role',
      },
      chk: {
        required: 'Please select the checkbox'
      }
    },
    errorPlacement: function (error, element) {
      if (element.is(":radio")) {
        error.appendTo('#role_err');
      } else if (element.is(":checkbox")) {
        error.appendTo('#checkbox_err');
      }
      else {
        error.insertAfter(element);
      }
    },
  });
});